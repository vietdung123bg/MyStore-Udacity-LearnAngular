export interface CartProduct {
  id: number;
  name: string;
  price: number;
  numberOfItem: number;
  url: string;
  description: string;
}
